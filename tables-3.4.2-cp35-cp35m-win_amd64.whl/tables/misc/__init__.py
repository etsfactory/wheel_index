# -*- coding: utf-8 -*-

########################################################################
#
# License: BSD
# Created:
# Author: Francesc Alted - faltet@pytables.com
#
# $Id$
#
########################################################################

"""Miscellaneous general-purpose modules

The purpose, authorship and license of modules in this package is
diverse, and they may be useful outside of PyTables.  Please read
their source code for further information.
"""
